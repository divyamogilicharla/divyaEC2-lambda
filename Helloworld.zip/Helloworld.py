import json
import boto3

def lambda_handler(event, context):
    
    aws_mng_con = boto3.Session(profile_name='default')
    ec2_client = boto3.client('ec2')
    cloudwatch = boto3.client('cloudwatch')
    sns = boto3.resource('sns')

    regions = ['ap-south-1']

    for region in regions:

        ec2 = boto3.resource('ec2', region_name=region)
        instances = ec2.instances.filter(
            Filters=[
                {'Name': 'tag:Name', 'Values': ['WebServer']}
            ]
        )
        CPUUtilization_template = '["AWS/EC2", "CPUUtilization", "InstanceId", "{}"]'
        CPUUtilization_array = []
        for i in instances.all():
                print(i.id)
                instance_id = i.id
                CPUUtilization_array.append(CPUUtilization_template.format(i.id))
        CPUUtilization_string = ",".join(CPUUtilization_array)
        CPUUtilization_instances = r'{"type": "metric", "x": 0, "y": 0, "width":24, "height":6, "properties": {"metrics": [template], "view": "timeSeries","stacked": false, "region": "us-east-2", "title": "EC2"}}'
        print(CPUUtilization_instances)

        response = cloudwatch.put_dashboard(DashboardName='EC2Lambda', DashboardBody= '{"widgets": ['+CPUUtilization_instances+']}')
        print(response)
        print(f"event: {event}")
        print(f"context: {context}")
        return {
            'statusCode': 200,
            'body' : json.dumps('Hello from Lambda')
        }
                                        